__version__ = "8.0.2"
__release__ = True
