# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

version_info = (4, 5, 0)

__version__ = '.'.join(map(str, version_info))
