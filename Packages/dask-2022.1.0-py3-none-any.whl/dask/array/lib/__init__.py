from . import stride_tricks
