import logging

# Keep test cases logging quiet
logging.basicConfig(level=logging.CRITICAL + 1)
