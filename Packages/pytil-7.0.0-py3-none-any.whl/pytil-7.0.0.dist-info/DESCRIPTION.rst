pytil (formerly known as Chicken Turtle Util) is a broad scoped Python utility
library.

Links
=====
- `Documentation <http://pytil.readthedocs.io/en/7.0.0/>`_
- `PyPI <https://pypi.python.org/pypi/pytil/>`_
- `GitHub <https://github.com/timdiels/pytil/>`_

See also
========
Some other utility libraries:

- `Toolz <https://toolz.readthedocs.io/en/latest/>`_
- `More Itertools <https://more-itertools.readthedocs.io/en/latest/>`_


