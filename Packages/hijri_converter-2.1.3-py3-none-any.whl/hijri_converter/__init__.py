"""Accurate Hijri-Gregorian date converter based on the Umm al-Qura calendar.

https://github.com/dralshehri/hijri-converter
"""

__version__ = "2.1.3"
