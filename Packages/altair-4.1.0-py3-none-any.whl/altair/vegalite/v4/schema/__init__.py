# flake8: noqa
from .core import *
from .channels import *
SCHEMA_VERSION = 'v4.8.1'
SCHEMA_URL = 'https://vega.github.io/schema/vega-lite/v4.8.1.json'
