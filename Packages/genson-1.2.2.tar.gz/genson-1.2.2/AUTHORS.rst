Credits
=======

**GenSON** is written and maintained by `Jon Wolverton <https://github.com/wolverdude>`_.


Contributors
------------

- `Brad Sokol <https://github.com/bradsokol>`_
- `David Kay <https://github.com/davek2>`_
- `Heiho1 <https://github.com/heiho1>`_
- `YehudaCorsia <https://github.com/YehudaCorsia>`_
