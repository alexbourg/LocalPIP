"""Initialize the Repo package"""
# flake8: noqa
from .base import Repo as Repo
