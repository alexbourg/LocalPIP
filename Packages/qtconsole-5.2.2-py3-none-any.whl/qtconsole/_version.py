version_info = (5, 2, 2)
__version__ = '.'.join(map(str, version_info))
