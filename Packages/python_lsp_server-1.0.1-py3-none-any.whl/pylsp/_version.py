# Copyright 2017-2020 Palantir Technologies, Inc.
# Copyright 2021- Python Language Server Contributors.

"""PyLSP versioning information."""


VERSION_INFO = (1, 0, 1)
__version__ = '.'.join(map(str, VERSION_INFO))
