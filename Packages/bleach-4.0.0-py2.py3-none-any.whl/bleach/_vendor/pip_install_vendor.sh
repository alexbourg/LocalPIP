#!/bin/bash


pip install --no-binary all --no-compile --no-deps -r vendor.txt --target .
