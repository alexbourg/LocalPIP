from .api import Coveralls
from .version import __version__


__all__ = ['Coveralls', '__version__']
