"""Input layer code (`Input` and `InputLayer`)."""
from tensorflow.keras.layers import InputLayer
from tensorflow.keras import Input

