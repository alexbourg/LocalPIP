"""Reuters topic classification dataset."""

from tensorflow.keras.datasets.reuters import load_data
from tensorflow.keras.datasets.reuters import get_word_index
