"""CIFAR10 small images classification dataset."""

from tensorflow.keras.datasets.cifar10 import load_data
