"""CIFAR100 small images classification dataset."""

from tensorflow.keras.datasets.cifar100 import load_data
