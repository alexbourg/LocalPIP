"""Multi-GPU training utilities."""

from tensorflow.keras.utils import multi_gpu_model
