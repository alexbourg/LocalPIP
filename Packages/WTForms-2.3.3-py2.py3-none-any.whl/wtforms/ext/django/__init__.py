import warnings

warnings.warn(
    "'wtforms.ext.django' will be removed in WTForms 3.0. Use"
    " wtforms-django instead."
    " https://github.com/wtforms/wtforms-django",
    DeprecationWarning,
)
