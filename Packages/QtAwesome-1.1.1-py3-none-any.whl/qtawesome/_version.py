version_info = (1, 1, 1)
__version__ = '.'.join(map(str, version_info))
