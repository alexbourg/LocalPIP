#
# -----------------------------------------------------------------------------
# Copyright (c) 2009- Spyder Kernels Contributors
#
# Licensed under the terms of the MIT License
# (see spyder_kernels/__init__.py for details)
# -----------------------------------------------------------------------------

"""Version File."""

VERSION_INFO = (2, 0, 1)
__version__ = '.'.join(map(str, VERSION_INFO))
