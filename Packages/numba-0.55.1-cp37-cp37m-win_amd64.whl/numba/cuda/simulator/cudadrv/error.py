class CudaSupportError(RuntimeError):
    pass
