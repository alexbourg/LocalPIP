# Expected to run this module as __main__


# Cloudpickle will think this is a dynamic class when this module is __main__
class Klass:
    classvar = None
