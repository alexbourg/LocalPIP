#
# SPDX-License-Identifier: BSD-2-Clause
# Copyright 2013-2021, John McNamara, jmcnamara@cpan.org
#
__version__ = '3.0.2'
__VERSION__ = __version__
from .workbook import Workbook
