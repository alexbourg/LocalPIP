import warnings

warnings.warn('tenable_io is being deprecated in favor of pyTenable', DeprecationWarning)

__version__ = "1.13.1"
__url__ = 'https://github.com/tenable/Tenable.io-SDK-for-Python'
__description__ = 'Python Interface into tenable.io'
