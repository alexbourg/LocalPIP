# Copyright 2017-2020 Palantir Technologies, Inc.
# Copyright 2021- Python Language Server Contributors.

VERSION_INFO = (1, 0, 0)
__version__ = '.'.join(map(str, VERSION_INFO))
