""" Version information """

__version__ = "2.5.1"
__version_info__ = (2, 5, 1)
