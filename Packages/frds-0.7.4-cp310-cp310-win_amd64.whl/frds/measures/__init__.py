r"""`frds.measures` package provides built-in measures.

"""
from .bank import *
from .corporate import *
from .general import *