# Temporary hotfix for flake8-docstrings
from .checker import ConventionChecker, check
from .parser import AllError
from .utils import __version__
from .violations import Error, conventions
