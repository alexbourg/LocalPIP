# -*- coding: utf-8 -*-
"""
This package contains the application example with all Qt elements.
"""
