#
# SPDX-License-Identifier: BSD-2-Clause
# Copyright 2013-2022, John McNamara, jmcnamara@cpan.org
#
__version__ = '3.0.3'
__VERSION__ = __version__
from .workbook import Workbook
