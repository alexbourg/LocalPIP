__title__ = 'python-socks'
__version__ = '1.2.4'
