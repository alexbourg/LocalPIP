class AsyncResolver:
    async def resolve(self, host, port=0, family=0):
        raise NotImplementedError()  # pragma: no cover
