"""Free Google Translate API for Python. Translates totally free of charge."""
__all__ = 'Translator',
__version__ = '2.4.2'


from googletransx.client import Translator
from googletransx.constants import LANGCODES, LANGUAGES
