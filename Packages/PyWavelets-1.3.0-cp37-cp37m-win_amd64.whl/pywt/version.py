
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '1.3.0'
version = '1.3.0'
full_version = '1.3.0'
git_revision = '6dab01587a7d89a158c1a2617638f6ffa69f5d08'
release = True

if not release:
    version = full_version
