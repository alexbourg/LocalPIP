import styleframe as sf
import os

tests_dir = os.path.join(os.path.dirname(sf.__file__), 'tests')
TEST_FILENAME = os.path.join(tests_dir, 'styleframe_test.xlsx')
