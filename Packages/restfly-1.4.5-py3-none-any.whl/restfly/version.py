'''
version info
'''
VERSION = '1.4.5'
version_info = tuple(
    int(d) for d in VERSION.split("-", maxsplit=1)[0].split(".")
)
