import unittest

from .test_core import *
from .test_commands import *


if __name__ == "__main__":
    unittest.main()
