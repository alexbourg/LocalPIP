from .widget import DeckGLWidget  # noqa
