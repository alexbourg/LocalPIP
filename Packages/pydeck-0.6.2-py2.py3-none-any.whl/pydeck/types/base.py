from abc import abstractmethod, ABC


class PydeckType(ABC):
    @abstractmethod
    def __init__(self):
        pass
